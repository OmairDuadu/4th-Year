Author: Omair Duadu
Date : 07/03/2022
Project : Laboratory Sheet 3 – AJAX and JSON
Description: BUild a website using node.js and add functionality adn effects using AJAX, Jquery, and JSON.

Steps to run the project:
1. open terminal and enter the Lab 3 - AJAX directory, then run node index.js

2. slide header :causes the header to slide up

3. Hide content : displays faes the 3 paragraphs gradually

4. Reveal table : 20 rows from the table

5. 20 rows : makes it so that 20 rows are reveled if there was more displayed

6. full table : displays the full table after the reveal 