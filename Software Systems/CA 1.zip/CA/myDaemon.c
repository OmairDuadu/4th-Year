// Date:06/11/2021
// Author: Omair Duadu
// Student Number: C18322011
// Project: Systems Software CA 1
// This program is used to create a process which will run different functions as part of a service.

#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <syslog.h>
#include <sys/stat.h>
#include <time.h>
#include "pathFile.h"
#include "backup.h"
#include "lockShared.h"
#include "transfer.h"
 
int main()
{
   time_t now;
   struct tm newyear;
   double seconds;
   time(&now);  /* get current time; same as: now = time(NULL)  */
   newyear = *localtime(&now);
   newyear.tm_hour = 22; //time is in 24-hour format!
   newyear.tm_min = 23;
   newyear.tm_sec = 0;


   // Implementation for Singleton Pattern if desired (Only one instance running)
   printf("Service Running \n");
   // Create a child process      
   int pid = fork();

   if (pid > 0) {
      // if PID > 0 :: this is the parent
      // this process performs printf and finishes
      printf("Parent process \n");
      sleep(10);  // uncomment to wait 10 seconds before process ends
      exit(EXIT_SUCCESS);
   } else if (pid == 0) {
      // Step 1: Create the orphan process
      printf("Child process\n");
      
      // Step 2: Elevate the orphan process to session leader, to loose controlling TTY
      // This command runs the process in a new session
      if (setsid() < 0) { exit(EXIT_FAILURE); }

      // We could fork here again , just to guarantee that the process is not a session leader
      int pid = fork();
      if (pid > 0) {
         exit(EXIT_SUCCESS);
      }
      else {      
         // Step 3: call umask() to set the file mode creation mask to 0
         // This will allow the daemon to read and write 
         // files with the permissions/access required
         umask(0);

         // Step 4: Change the current working dir to root.
         // This will eliminate any issues of running on a mounted drive,
         // that potentially could be removed etc..
         if (chdir("/") < 0 ) { exit(EXIT_FAILURE); }

         // Step 5: Close all open file descriptors
         /* Close all open file descriptors */
         // int x;
         // for (x = sysconf(_SC_OPEN_MAX); x>=0; x--){
         //     close (x);
         // }

         
         // Log file goes syslog and auditctl
         openlog("mainProgram",LOG_PID|LOG_CONS,LOG_LOCAL0);
         system("grep -i \"Daemon:\" /var/log/syslog  >> /home/jombo/Desktop/CA/logs/syslog.txt"); //syslogs

         syslog(LOG_INFO,"Daemon: Creating the user access log file");
         system("sudo /usr/sbin/auditctl -w " SHARED " -p rwxa");
         system("sudo /usr/sbin/ausearch -f " SHARED " | sudo aureport -f -i > " LOGS "accesslog.txt");
         

         // Orphan Logic goes here!!
         // Keep process running with infinite loop
         // When the parent finishes after 10 seconds,
         // the getppid() will return 1 as the parent (init process)
      
         while(1) {
            sleep(1);
            time(&now);
            seconds = difftime(now,mktime(&newyear));
            printf("\n%.f", seconds);
            if (seconds == 0) {
               //Starting Main functionality
               char mode[5] = "0000";
               char path[100] = "/home/jombo/Plant/";
               lockShared(mode,path);  //function for perimssions
               transfer();             //function for transfer process
               backup();               //function for Backup process
               
            }
            else{

            } 
         }

         
      }
   }

   return 0;
}