//Storing paths in configurable variables using #define 
#define SHARED "/home/jombo/Plant/Shared/"
#define LOGS "/home/jombo/Desktop/CA/logs/"
#define LIVE "/home/jombo/Plant/Dashboard/"
#define BACKUP "/home/jombo/Plant/backup.zip/$(date +\"%d-%m-%Y\")"

//These are file checking.
#define distribution "/home/jombo/Plant/Shared/Distribution.xml"
#define manufacturing "/home/jombo/Plant/Shared/Manufacturing.xml"
#define sales "/home/jombo/Plant/Shared/Sales.xml"
#define warehouse "/home/jombo/Plant/Shared/Warehouse.xml"
