//Permission locking function for Daemon Service
#include <stdio.h>
#include <stdlib.h>
#include <syslog.h>
#include <sys/stat.h>
#include "pathFile.h"

void lockShared(char mode[], char path[])
{
    //syslog and printf
    syslog(LOG_INFO, " Daemon: Locking Shared and Dashboard Directories");
    printf("Locking Shared and Dashboard Directories\n");

    //changing permissions
    int i;
    i = strtol(mode, 0, 8);
    return chmod(path, i);
}
