#ifndef LOCK
#define LOCK

void lockShared();

#endif