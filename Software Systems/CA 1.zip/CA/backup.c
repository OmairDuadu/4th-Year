//Backup function for daemon service
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <syslog.h>
#include "pathFile.h"
#include "lockShared.h"

void backup(void){

    //Logging
    syslog(LOG_INFO, "Daemon: Starting Backup of Dashboard");
    printf("Starting Backup of Dashboard.\n");

    //Backup functionality with included loging
    system("mkdir " BACKUP);
    if(system("rsync -a " LIVE " " BACKUP)==-1)
    {
        syslog(LOG_ERR, "Daemon: Backup not complete. \n");

    }else{
        syslog(LOG_INFO, "Daemon: Finished Backup of Dashboard");
        printf("Finished Backup of Dashboard.\n");
    }
    
    //Restoring Permissions after Backup
    char mode[5] = "0777";
    char path[100] = "/home/jombo/Plant/";
    lockShared(mode,path);
}