//Transfer function for Daemon Service
#include <stdio.h>
#include <stdlib.h>
#include <sys/stat.h>
#include "pathFile.h"
#include <syslog.h>
#include <unistd.h>
#include "lockShared.h"


void transfer(void){

    syslog(LOG_INFO, "Daemon: Starting Transfer");
    printf("Starting Transfer.\n");

    //transfer functionality with logging
    if (system("rsync -a " SHARED " " LIVE) == -1)
    {
        syslog(LOG_ERR, "Daemon: Transfer not complete. \n");
    }else{
        syslog(LOG_INFO, "Daemon: Transfer complete. \n");
        printf("Transfer Complete! \n");
    }
       
    //array for files being uploaded 
    const char file_checker[4][100] = {
        distribution,
        manufacturing,
        sales,
        warehouse
    };

    //logging for files that are present
    for(int i = 0; i < 4; i++){
        if(access(file_checker[i], F_OK) == 0){
            syslog(LOG_INFO, "Daemon: Report found for: %s",file_checker[i]);}
        else{
            syslog(LOG_INFO, "Daemon: Report not found for: %s",file_checker[i]);}
    }
}